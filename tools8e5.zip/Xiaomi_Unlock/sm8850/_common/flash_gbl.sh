#!/system/bin/sh
[ -f /metadata/ota/state ] && grep -qE "^(Initiated|Unverified)$" /metadata/ota/state && exit 3
[ -f /data/local/tmp/gbl_efi_unlock.efi ] || exit 2
[ -f /data/local/tmp/abl.img ] || exit 2
dd if=/data/local/tmp/gbl_efi_unlock.efi of=/dev/block/by-name/efisp || exit 1
dd if=/data/local/tmp/abl.img of=/dev/block/by-name/abl_a || exit 1
dd if=/data/local/tmp/abl.img of=/dev/block/by-name/abl_b || exit 1
sync
