@echo off
mkdir .\output
pushd .\output
..\tools\kallsyms_lookup\kallsyms_lookup13.exe ..\output\kernel ..\output
popd
pause