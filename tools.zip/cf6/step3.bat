@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

REM --- 设定 adb 路径 ---
set "ADB_PATH=.\tools\platform_tools\adb.exe"

if not exist "%ADB_PATH%" (
    echo [err] can't find adb at "%ADB_PATH%"
	pause
    exit /b 1
)

REM --- 1. push cf ---
"%ADB_PATH%" push .\tools\setup_selinux\cf /data/local/tmp/
if errorlevel 1 (
    echo [error] push failed.
	pause
    exit /b 1
)

REM --- 2. 从输出文件中提取地址 ---
set "file=.\output\selinux_state_address.txt"
if not exist "%file%" (
    echo [error] %file% doesn't exist.
	pause
    exit /b 1
)

set "lastline="
for /f "usebackq delims=" %%a in (`type "%file%"`) do set "lastline=%%a"

set "va="
for %%b in (!lastline!) do set "va=%%b"

if "%va%"=="" (
    echo [error] can't find addr.
	pause
    exit /b 1
)
echo selinux_state virtual address: %va%

REM --- 3. 把要执行的命令复制到剪贴板 ---
powershell -Command "Set-Clipboard -Value 'cd /data/local/tmp && chmod +x cf && export SELINUX_VATUAL=%va% && ./cf'"

echo.
echo 已将以下命令复制到剪贴板:
echo cd /data/local/tmp ^&^& chmod +x cf ^&^& export SELINUX_VATUAL=%va% ^&^& ./cf
echo.

REM --- 4. 打开新的 adb shell 窗口 ---
start "adb shell" "%ADB_PATH%" shell

echo 已启动 adb shell 窗口，请切换过去，点击右键粘贴并回车即可。
pause