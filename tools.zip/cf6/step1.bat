@echo off
mkdir .\output
pushd .\output
..\tools\MagiskBootWindows-main\magiskboot.exe unpack ..\boot.img
popd
pause